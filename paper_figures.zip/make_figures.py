#!/usr/bin/env python3
"""
make_figures.py — builds every paper figure strictly from raw experiment logs.
Inputs:  graph/  (results_pending.zip contents)   pw/results_proofwriter_addon/
Outputs: figures/*.pdf + *.png
Part of the code release: anyone can regenerate the figures from the logs.
"""
import json, glob, os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams.update({
    "font.size": 9, "axes.titlesize": 10, "axes.labelsize": 9,
    "legend.fontsize": 8, "figure.dpi": 150, "savefig.bbox": "tight",
    "axes.spines.top": False, "axes.spines.right": False,
})
# colorblind-safe palette
C = {"A": "#0173B2", "B": "#DE8F05", "C": "#029E73", "D": "#949494", "E": "#CC78BC",
     "full": "#0173B2", "z0sub": "#DE8F05", "zeroed": "#949494"}
os.makedirs("figures", exist_ok=True)

def read_run(path):
    manifest, epochs, final = None, [], None
    for line in open(path):
        r = json.loads(line)
        if r["type"] == "manifest": manifest = r
        elif r["type"] == "epoch": epochs.append(r)
        elif r["type"] == "final": final = r
    return manifest, epochs, final

def runs(pattern):
    return {os.path.basename(p).replace(".jsonl", ""): read_run(p)
            for p in sorted(glob.glob(pattern))}

G = runs("graph/arm*.jsonl")
PW = runs("pw/results_proofwriter_addon/*.jsonl")

# ============================================================================
# FIG 1 — Lazy identity: training-time displacement ||h* - start|| per arm
# ============================================================================
fig, ax = plt.subplots(figsize=(4.6, 2.9))
theory_B = 2.0 * np.sqrt(16 - 0.5)   # sigma * E||N(0, I_16)|| (approx sqrt(d-1/2))
for arm, label in [("A", "A: coupled (start = anchor = $z_0$)"),
                   ("B", "B: decoupled (start = $z_0 + \\sigma\\varepsilon$)"),
                   ("C", "C: no anchor ($r_{\\mathrm{anchor}}=0$)")]:
    first = True
    for k, (m, eps, fin) in G.items():
        if not k.startswith(f"arm{arm}_"): continue
        e = [r["epoch"] for r in eps]; d = [r["z0_disp"] for r in eps]
        ax.plot(e, d, color=C[arm], lw=0.9, alpha=0.75,
                label=label if first else None)
        first = False
ax.axhline(theory_B, color=C["B"], ls=":", lw=1,
           label=r"$\sigma\,\mathbb{E}\|\varepsilon\|\approx 7.87$ (noise norm)")
ax.set_xlabel("training epoch")
ax.set_ylabel(r"mean $\|h^{*} - \mathrm{start}\|$ (train)")
ax.set_title("The equilibrium is the start point (graph task, 5 seeds/arm)")
ax.set_ylim(-0.4, 9.2)
ax.legend(loc="center right", frameon=False)
fig.savefig("figures/fig1_lazy_identity.pdf"); fig.savefig("figures/fig1_lazy_identity.png")
plt.close(fig)

# ============================================================================
# FIG 2 — Substitution/ablation bars, both tasks
# ============================================================================
fig, axes = plt.subplots(1, 2, figsize=(7.6, 2.9), gridspec_kw={"width_ratios": [1.15, 1]})
# --- left: graph task, arms A/B/C/E: full vs z0-sub vs zeroed; arm D as line
ax = axes[0]
arms = ["A", "B", "C", "E"]
labels = ["A\ncoupled", "B\ndecoupled\nretrain", "C\nno\nanchor", "E\n30k\ngraphs"]
width = 0.26
for j, (key, name) in enumerate([("full_acc", "full pipeline"),
                                 ("z0_sub_acc", "start-substituted (solver bypassed)"),
                                 ("hstar_zeroed_acc", "$h^{*}$ zeroed")]):
    means, stds = [], []
    for arm in arms:
        vals = [fin[key] for k, (m, e, fin) in G.items()
                if k.startswith(f"arm{arm}_") or (arm == "E" and k.startswith("armE"))]
        means.append(np.mean(vals)); stds.append(np.std(vals, ddof=1))
    ax.bar(np.arange(len(arms)) + (j - 1) * width, means, width, yerr=stds,
           color=list(C.values())[5 + j], capsize=2, label=name,
           error_kw={"lw": 0.8})
dvals = [fin["full_acc"] for k, (m, e, fin) in G.items() if k.startswith("armD")]
ax.axhline(np.mean(dvals), color="k", ls="--", lw=1,
           label=f"D: context-only baseline ({np.mean(dvals):.1f}%)")
ax.axhspan(np.mean(dvals) - np.std(dvals, ddof=1), np.mean(dvals) + np.std(dvals, ddof=1),
           color="k", alpha=0.08, lw=0)
ax.set_xticks(range(len(arms))); ax.set_xticklabels(labels)
ax.set_ylabel("test accuracy (%)"); ax.set_ylim(40, 70)
ax.set_title("Graph reachability (mean ± std over seeds)")
ax.legend(frameon=False, loc="lower right", fontsize=6.5)
# --- right: ProofWriter per-seed triads (bimodality visible)
ax = axes[1]
seeds = sorted(PW)
x = np.arange(len(seeds))
for j, (key, name) in enumerate([("full_acc", "full"), ("z0_sub_acc", "start-sub"),
                                 ("hstar_zeroed_acc", "$h^{*}$ zeroed")]):
    vals = [PW[s][2][key] for s in seeds]
    ax.bar(x + (j - 1) * width, vals, width, color=list(C.values())[5 + j], label=name)
bvals = [PW[s][2]["baseline_acc"] for s in seeds]
ax.axhline(np.mean(bvals), color="k", ls="--", lw=1,
           label=f"MLP baseline ({np.mean(bvals):.1f}%)")
ax.axhline(50, color="k", ls=":", lw=0.7)
ax.text(len(seeds) - 0.45, 51, "chance", fontsize=6.5)
ax.annotate("blow-up regime\n($\\|h^{*}-z_0\\|=171$)", xy=(2, 84), xytext=(0.62, 97),
            fontsize=6.5, arrowprops=dict(arrowstyle="->", lw=0.7))
ax.set_xticks(x); ax.set_xticklabels([f"seed {i+1}" for i in range(len(seeds))])
ax.set_ylabel("test accuracy (%)"); ax.set_ylim(25, 103)
ax.set_title("ProofWriter (per seed — two regimes)")
ax.legend(frameon=False, loc="lower left", fontsize=6.5)
fig.savefig("figures/fig2_substitution.pdf"); fig.savefig("figures/fig2_substitution.png")
plt.close(fig)

# ============================================================================
# FIG 3 — Iteration counts ignore difficulty
# ============================================================================
fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.7))
ax = axes[0]
for arm in ["A", "B"]:
    Ks = np.concatenate([np.load(p)["K"] for p in sorted(glob.glob(f"graph/arm{arm}_*_K.npz"))])
    ax.hist(Ks, bins=np.arange(0, 305, 10), color=C[arm], alpha=0.65,
            label=f"arm {arm} (mean K = {Ks.mean():.0f})")
ax.set_yscale("log")
ax.set_xlabel("solver iterations $K$"); ax.set_ylabel("count (log)")
ax.set_title("Iteration histogram (test set, 5 seeds pooled)")
ax.legend(frameon=False)
ax = axes[1]
for arm, off in [("A", -0.12), ("E", 0.12)]:
    pat = f"graph/arm{arm}_*_K.npz" if arm != "E" else "graph/armE_*_K.npz"
    Ks = np.concatenate([np.load(p)["K"] for p in sorted(glob.glob(pat))])
    Ds = np.concatenate([np.load(p)["dist"] for p in sorted(glob.glob(pat))])
    valid = Ds >= 0
    dsu = np.unique(Ds[valid])
    means = [Ks[valid][Ds[valid] == d].mean() for d in dsu]
    stds = [Ks[valid][Ds[valid] == d].std() for d in dsu]
    r = np.corrcoef(Ks[valid], Ds[valid])[0, 1]
    ax.errorbar(dsu + off, means, yerr=stds, fmt="o-", ms=3, lw=1, capsize=2,
                color=C[arm], label=f"arm {arm}: corr = {r:.3f}")
ax.set_xlabel("true BFS distance (difficulty)")
ax.set_ylabel("solver iterations $K$")
ax.set_ylim(280, 305)
ax.set_title("No adaptive computation")
ax.legend(frameon=False, loc="lower right")
fig.savefig("figures/fig3_iterations.pdf"); fig.savefig("figures/fig3_iterations.png")
plt.close(fig)

# ============================================================================
# FIG 4 — Two degenerate regimes (ProofWriter): gap vs displacement
# ============================================================================
fig, ax = plt.subplots(figsize=(4.2, 2.9))
disp = np.array([PW[s][2]["mean_z0_disp"] for s in sorted(PW)])
gap = np.array([PW[s][2]["gap_pp"] for s in sorted(PW)])
zeroed_delta = np.array([PW[s][2]["hstar_zeroed_acc"] - PW[s][2]["full_acc"] for s in sorted(PW)])
disp_plot = np.clip(disp, 1e-7, None)
sc = ax.scatter(disp_plot, gap, s=55, c=["#0173B2"] * 2 + ["#D55E00"] + ["#0173B2"] * 2,
                zorder=3, edgecolor="k", lw=0.4)
for i, s in enumerate(sorted(PW)):
    ax.annotate(f"seed {i+1}", (disp_plot[i], gap[i]), textcoords="offset points",
                xytext=(6, 4), fontsize=6.5)
ax.set_xscale("log")
ax.axvspan(1e-7, 1.0, color="#0173B2", alpha=0.06, lw=0)
ax.axvspan(1.0, 500, color="#D55E00", alpha=0.06, lw=0)
ax.text(3e-6, 38, "lazy identity collapse\n(equilibrium ≡ start,\nsolver contributes +0.00pp)",
        fontsize=7, color="#0173B2")
ax.text(3.0, 12, "solver blow-up\n(non-converged $h^{*}$ =\ndecoder-adapted noise;\nzeroing it *improves* acc)",
        fontsize=7, color="#D55E00")
ax.set_xlabel(r"mean $\|h^{*} - z_0\|$ (log scale)")
ax.set_ylabel("gap = full − start-substituted (pp)")
ax.set_title("ProofWriter: two regimes, zero useful computation")
fig.savefig("figures/fig4_two_regimes.pdf"); fig.savefig("figures/fig4_two_regimes.png")
plt.close(fig)

# ============================================================================
# FIG 5 (appendix) — training curves per arm (graph)
# ============================================================================
fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.6))
for arm in ["A", "B", "C", "E"]:
    for k, (m, eps, fin) in G.items():
        if not k.startswith(f"arm{arm}"): continue
        axes[0].plot([r["epoch"] for r in eps], [r["loss"] for r in eps],
                     color=C[arm], lw=0.7, alpha=0.6)
        axes[1].plot([r["epoch"] for r in eps], [r["train_acc"] for r in eps],
                     color=C[arm], lw=0.7, alpha=0.6)
for ax, ylab in [(axes[0], "train loss"), (axes[1], "train accuracy (%)")]:
    ax.set_xlabel("epoch"); ax.set_ylabel(ylab)
handles = [plt.Line2D([], [], color=C[a], label=f"arm {a}") for a in ["A", "B", "C", "E"]]
axes[0].legend(handles=handles, frameon=False, fontsize=6.5)
axes[0].set_yscale("log")
fig.suptitle("Training curves, graph task (all seeds)", y=1.02, fontsize=10)
fig.savefig("figures/fig5_training_curves.pdf"); fig.savefig("figures/fig5_training_curves.png")
plt.close(fig)

print("figures written:", sorted(os.listdir("figures")))
