| metric | mean ± std (n=5) |
|---|---|
| Full pipeline acc | 89.39 ± 4.30 |
| z0-substituted acc | 79.61 ± 26.30 |
| Gap (full − z0-sub), pp | 9.77 ± 22.04 |
| h*-zeroed acc (confounded ablation) | 56.87 ± 14.96 |
| Mean ‖h*−z0‖ | 3.43e+01 ± 7.67e+01 |
| Baseline MLP acc (no DEQ, fresh per seed) | 90.39 ± 0.33 |
